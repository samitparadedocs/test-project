package com.example.macysdemo.repository;

import com.example.macysdemo.model.NoShippingList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

@Repository
public class NoShippingListRepository {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public List<NoShippingList> findAll() {
        return jdbcTemplate.query("SELECT noshippinglistid, title, locationname, modifiedon, createdby, modifiedby FROM ticketadmin.tkt_noshippinglist", this::mapRowToNoShippingList);
    }

    public Optional<NoShippingList> findById(int id) {
        try {
            return Optional.ofNullable(jdbcTemplate.queryForObject("SELECT * FROM ticketadmin.tkt_noshippinglist WHERE noshippinglistid = ?", new Object[]{id}, this::mapRowToNoShippingList));
        } catch (org.springframework.dao.EmptyResultDataAccessException e) {
            return Optional.empty();
        }
    }

    public int save(NoShippingList noShippingList) {
        return jdbcTemplate.update("INSERT INTO ticketadmin.tkt_noshippinglist (title, locationname, createdby, modifiedby) VALUES (?, ?, ?, ?)",
                noShippingList.getTitle(), noShippingList.getLocationName(), noShippingList.getCreatedBy(), noShippingList.getModifiedBy());
    }

    public int update(NoShippingList noShippingList) {
        return jdbcTemplate.update("UPDATE ticketadmin.tkt_noshippinglist SET title = ?, locationname = ?, modifiedby = ? WHERE noshippinglistid = ?",
                noShippingList.getTitle(), noShippingList.getLocationName(), noShippingList.getModifiedBy(), noShippingList.getNoShippingListId());
    }

    public int deleteById(int id) {
        return jdbcTemplate.update("DELETE FROM ticketadmin.tkt_noshippinglist WHERE noshippinglistid = ?", id);
    }

    private NoShippingList mapRowToNoShippingList(ResultSet rs, int rowNum) throws SQLException {
        NoShippingList noShippingList = new NoShippingList();
        noShippingList.setNoShippingListId(rs.getInt("noshippinglistid"));
        noShippingList.setTitle(rs.getString("title"));
        noShippingList.setLocationName(rs.getString("locationname"));
       // noShippingList.setModifiedOn(rs.getTimestamp("modifiedon").toLocalDateTime());
        noShippingList.setCreatedBy(rs.getString("createdby"));
        noShippingList.setModifiedBy(rs.getString("modifiedby"));
        return noShippingList;
    }
}
