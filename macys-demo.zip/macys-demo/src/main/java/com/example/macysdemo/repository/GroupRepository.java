package com.example.macysdemo.repository;

import com.example.macysdemo.model.Group;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

@Repository
public class GroupRepository {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public List<Group> findAll() {
        return jdbcTemplate.query("SELECT groupid, groupname, sendinvitations, createdon FROM ticketadmin.tkt_group", this::mapRowToGroup);
    }

    public Optional<Group> findById(int id) {
        try {
            return Optional.ofNullable(jdbcTemplate.queryForObject("SELECT groupid, groupname, sendinvitations, createdon FROM ticketadmin.tkt_group WHERE groupid = ?", new Object[]{id}, this::mapRowToGroup));
        } catch (org.springframework.dao.EmptyResultDataAccessException e) {
            return Optional.empty();
        }
    }

    public int save(Group group) {
        return jdbcTemplate.update("INSERT INTO ticketadmin.tkt_group (groupname, sendinvitations, createdon) VALUES (?, ?, ?)",
                group.getGroupName(), group.isSendInvitations(), group.getCreatedOn());
    }

    public int deleteById(int id) {
        return jdbcTemplate.update("DELETE FROM ticketadmin.tkt_group WHERE groupid = ?", id);
    }

    private Group mapRowToGroup(ResultSet rs, int rowNum) throws SQLException {
        Group group = new Group();
        group.setGroupId(rs.getInt("groupid"));
        group.setGroupName(rs.getString("groupname"));
        group.setSendInvitations(rs.getString("sendinvitations"));
        group.setCreatedOn(rs.getTimestamp("createdon").toLocalDateTime());
        return group;
    }
}
