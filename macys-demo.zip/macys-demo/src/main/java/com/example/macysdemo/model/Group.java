package com.example.macysdemo.model;

import java.time.LocalDateTime;

public class Group {

    private int groupid;
    private String groupname;
    private String sendinvitations;
    private LocalDateTime createdon;

    // Getters and Setters

    public int getGroupId() {
        return groupid;
    }

    public void setGroupId(int groupid) {
        this.groupid = groupid;
    }

    public String getGroupName() {
        return groupname;
    }

    public void setGroupName(String groupname) {
        this.groupname = groupname;
    }

    public String isSendInvitations() {
        return sendinvitations;
    }

    public void setSendInvitations(String sendinvitations) {
        this.sendinvitations = sendinvitations;
    }

    public LocalDateTime getCreatedOn() {
        return createdon;
    }

    public void setCreatedOn(LocalDateTime createdon) {
        this.createdon = createdon;
    }
}
