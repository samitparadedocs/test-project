package com.example.macysdemo.controller;

import com.example.macysdemo.exception.ResourceNotFoundException;
import com.example.macysdemo.model.Group;
import com.example.macysdemo.repository.GroupRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/groups")
public class GroupController {

    @Autowired
    private GroupRepository groupRepository;

    @Operation(summary = "Get all groups", description = "Returns a list of all groups")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved list"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    @GetMapping
    public List<Group> getAllGroups() {
        return groupRepository.findAll();
    }

    @Operation(summary = "Get group by ID", description = "Returns a single group")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved group"),
            @ApiResponse(responseCode = "404", description = "Group not found"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    @GetMapping("/{id}")
    public Group getGroupById(@PathVariable int id) {
        return groupRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Group not found with id: " + id));
    }

    @Operation(summary = "Add a new group", description = "Creates a new group")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Group created successfully"),
            @ApiResponse(responseCode = "400", description = "Invalid input"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    @PostMapping
    public int addGroup(@RequestBody Group group) {
        return groupRepository.save(group);
    }

    @Operation(summary = "Delete a group by ID", description = "Deletes a group by its ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Group deleted successfully"),
            @ApiResponse(responseCode = "404", description = "Group not found"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    @DeleteMapping("/{id}")
    public int deleteGroup(@PathVariable int id) {
        return groupRepository.deleteById(id);
    }
}
