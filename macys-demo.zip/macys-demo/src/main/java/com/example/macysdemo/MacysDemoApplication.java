package com.example.macysdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MacysDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MacysDemoApplication.class, args);
	}

}
