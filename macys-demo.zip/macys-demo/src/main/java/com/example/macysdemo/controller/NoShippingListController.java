package com.example.macysdemo.controller;

import com.example.macysdemo.exception.ResourceNotFoundException;
import com.example.macysdemo.model.NoShippingList;
import com.example.macysdemo.repository.NoShippingListRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/noshippinglist")
@Tag(name = "No Shipping List", description = "APIs for tks_noshippinglist")
public class NoShippingListController {

    @Autowired
    private NoShippingListRepository noShippingListRepository;

    @GetMapping
    @Operation(summary = "Get all no shipping lists")
    public List<NoShippingList> getAllNoShippingLists() {
        return noShippingListRepository.findAll();
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get a no shipping list by id")
    public NoShippingList getNoShippingListById(@PathVariable int id) {
        return noShippingListRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("No shipping list not found with id: " + id));
    }

    @PostMapping
    @Operation(summary = "Add a new no shipping list")
    public int addNoShippingList(@RequestBody NoShippingList noShippingList) {
        return noShippingListRepository.save(noShippingList);
    }

    @PutMapping
    @Operation(summary = "Update a no shipping list")
    public int updateNoShippingList(@RequestBody NoShippingList noShippingList) {
        return noShippingListRepository.update(noShippingList);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete a no shipping list by id")
    public int deleteNoShippingList(@PathVariable int id) {
        return noShippingListRepository.deleteById(id);
    }
}
