package com.example.macysdemo.model;

import java.time.LocalDateTime;

public class NoShippingList {

    private int noshippinglistid;
    private String title;
    private String locationname;
    private LocalDateTime modifiedon;
    private String createdby;
    private String modifiedby;

    // Getters and Setters

    public int getNoShippingListId() {
        return noshippinglistid;
    }

    public void setNoShippingListId(int noshippinglistid) {
        this.noshippinglistid = noshippinglistid;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getLocationName() {
        return locationname;
    }

    public void setLocationName(String locationname) {
        this.locationname = locationname;
    }

    public LocalDateTime getModifiedOn() {
        return modifiedon;
    }

    public void setModifiedOn(LocalDateTime modifiedon) {
        this.modifiedon = modifiedon;
    }

    public String getCreatedBy() {
        return createdby;
    }

    public void setCreatedBy(String createdby) {
        this.createdby = createdby;
    }

    public String getModifiedBy() {
        return modifiedby;
    }

    public void setModifiedBy(String modifiedby) {
        this.modifiedby = modifiedby;
    }
}
